#!/usr/bin/perl -w

$answer = 1 + 7 * 7 - 8;
print "$answer\n";
