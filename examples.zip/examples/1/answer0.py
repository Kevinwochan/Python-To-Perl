#!/usr/bin/python3

answer = 42
print(answer)